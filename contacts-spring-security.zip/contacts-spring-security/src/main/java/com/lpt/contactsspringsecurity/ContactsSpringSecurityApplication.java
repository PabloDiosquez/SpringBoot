package com.lpt.contactsspringsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactsSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactsSpringSecurityApplication.class, args);
	}

}
